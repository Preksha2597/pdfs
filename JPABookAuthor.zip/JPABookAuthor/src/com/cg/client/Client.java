package com.cg.client;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Scanner;

import com.cg.entities.Author;
import com.cg.entities.Book;
import com.cg.services.BAServiceImpl;
import com.cg.services.IBAService;

public class Client {
	public static void main(String[] args) throws IOException {
		Scanner sc=new Scanner(System.in);
		IBAService service=new BAServiceImpl();
		BufferedReader br=new BufferedReader(new InputStreamReader(System.in));
		while(true) {
			System.out.println("\nEnter Your Choice: ");
			System.out.println("1. Add New Book");
			System.out.println("2. Add New Author");
			System.out.println("3. Display All Books");
			System.out.println("4. Display All Books Of A Author");
			System.out.println("5. Display All Books In Price Range");
			System.out.println("6. Get Author By Book ID");
			System.out.println("7. Exit");
			int m=sc.nextInt();
			switch(m) {
			case 1:
				Book b1=new Book();
				Author a1=new Author();
				System.out.println("Enter Book Name: ");
				b1.setBname(br.readLine());
				System.out.println("Enter Price: ");
				b1.setBprice(sc.nextDouble());
				System.out.println("Do You Know Author ID ?\n1. Yes\n2. No");
				int input=sc.nextInt();
				switch(input) {
				case 1:
					
					break;
				case 2:
					System.out.println("Enter Author Name: ");
					a1.setAname(br.readLine());
					service.addBook(b1);
					service.addAuthor(a1);
					b1.setAuthor(a1);
					a1.setBooks(b1);
					System.out.println("Book Added: "+b1);
					break;
				default:
					System.out.println("Invalid Input");
				}
				break;
			case 2:
				Author a2=new Author();
				System.out.println("Enter Author Name: ");
				a2.setAname(br.readLine());
				service.addAuthor(a2);
				System.out.println("Author Added: "+a2);
				break;
			case 3:
				int count5=0;
				for(Book book:service.display()) {
					System.out.println(book);
					count5++;
				}
				if(count5==0)
					System.out.println("No Book(s) Added Yet");
				break;
			case 4:
				System.out.println("Enter The Author Whose Book You Want: ");
				String model6=br.readLine();
				int count6=0;
				for(Book book:service.displayByModel(model6)) {
					System.out.println(book);
					count6++;
				}
				if(count6==0)
					System.out.println("No Book Of Model "+model6);
				break;
			case 5:
				System.out.println("Enter Minimum Price: ");
				double low=sc.nextDouble();
				System.out.println("Enter Maximum Price: ");
				double high=sc.nextDouble();
				int count7=0;
				for(Book book:service.displayBooksInRange(low, high)) {
					System.out.println(book);
					count7++;
				}
				if(count7==0)
					System.out.println("No Book(s) In Price Range "+low+" And "+high);
				break;
			case 6:
				break;
			case 7:
				System.out.println("Good Bye");
				System.exit(0);
				break;
			}
		}
	}
}
