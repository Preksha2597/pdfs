package com.cg.services;

import java.util.List;

import com.cg.entities.Author;
import com.cg.entities.Book;

public interface IBAService {
	public abstract List<Book> display();
	public abstract List<Book> displayByModel(String author);
	public abstract List<Book> displayBooksInRange(double low, double high);
	public abstract String authorName(int id);
	public abstract void addBook(Book b);
	public abstract void addAuthor(Author a);
}
