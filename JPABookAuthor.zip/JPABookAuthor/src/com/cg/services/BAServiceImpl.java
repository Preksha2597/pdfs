package com.cg.services;

import java.util.List;

import com.cg.dao.BADaoImpl;
import com.cg.dao.IBADao;
import com.cg.entities.Author;
import com.cg.entities.Book;

public class BAServiceImpl implements IBAService {
	private IBADao dao;
	public BAServiceImpl() {
		dao = new BADaoImpl();
	}

	@Override
	public List<Book> display() {
		return dao.display();
	}

	@Override
	public List<Book> displayByModel(String author) {
		return dao.displayByModel(author);
	}

	@Override
	public List<Book> displayBooksInRange(double low, double high) {
		return dao.displayBooksInRange(low, high);
	}

	@Override
	public String authorName(int id) {
		return dao.authorName(id);
	}

	@Override
	public void addBook(Book b) {
		dao.beginTransaction();
		dao.addBook(b);
		dao.commitTransaction();
	}

	@Override
	public void addAuthor(Author a) {
		dao.beginTransaction();
		dao.addAuthor(a);
		dao.commitTransaction();
	}

}
