package com.cg.entities;
import java.io.Serializable;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="Book")
@SequenceGenerator(name="BookIDSequence", initialValue=1, allocationSize=101)
@NamedQueries(@NamedQuery(name="getAllBooks", query="SELECT book FROM Book book"))
public class Book implements Serializable{
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="BookIDSequence")
	private int bid;
	private String bname;
	private double bprice;
	
	@ManyToOne
	@JoinColumn(name="aid")
	private Author author;

	public int getBid() {
		return bid;
	}

	public void setBid(int bid) {
		this.bid = bid;
	}

	public String getBname() {
		return bname;
	}

	public void setBname(String bname) {
		this.bname = bname;
	}

	public double getBprice() {
		return bprice;
	}

	public void setBprice(double bprice) {
		this.bprice = bprice;
	}

	public Author getAuthor() {
		return author;
	}

	public void setAuthor(Author author) {
		this.author = author;
	}

	@Override
	public String toString() {
		return "Book-> Book ID: " + bid + ", Book Name: " + bname + ", Book Price: " + bprice + ", Author: " + author + "\n";
	}
	
	
}