package com.cg.entities;

import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="Author")
@SequenceGenerator(name="AuthorIDSequence", initialValue=1, allocationSize=500)
public class Author {
	@Id
	@GeneratedValue(strategy=GenerationType.SEQUENCE, generator="AuthorIDSequence")
	private int aid;
	private String aname;
	
	@OneToMany(mappedBy="author",cascade=CascadeType.ALL)
	private Set<Book> books = new HashSet<>();
	//to avoid null pointer exception

	public int getAid() {
		return aid;
	}

	public void setAid(int aid) {
		this.aid = aid;
	}

	public String getAname() {
		return aname;
	}

	public void setAname(String aname) {
		this.aname = aname;
	}

	public Set<Book> getBooks() {
		return books;
	}

	public void setBooks(Set<Book> books) {
		this.books = books;
	}

	@Override
	public String toString() {
		return "Author-> Author ID: " + aid + ", Author Name: " + aname + ", Books: " + books + "\n";
	}
	
	
	
}
