package com.cg.dao;

import java.util.List;

import com.cg.entities.Book;
import com.cg.entities.Author;

public interface IBADao {
	public abstract List<Book> display();
	public abstract List<Book> displayByModel(String author);
	public abstract List<Book> displayBooksInRange(double low, double high);
	public abstract String authorName(int id);
	public abstract void commitTransaction();
	public abstract void beginTransaction();
	public abstract void addBook(Book b);
	public abstract void addAuthor(Author a);
}
