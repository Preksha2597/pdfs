package com.cg.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.cg.entities.Author;
import com.cg.entities.Book;

public class BADaoImpl implements IBADao {
	private EntityManager em;
	public BADaoImpl() {
		em=JPAUtil.getEntityManager();
	}

	@Override
	public List<Book> display() {
		Query query = em.createNamedQuery("getAllBooks");
		@SuppressWarnings("unchecked")
		List<Book> bookList = query.getResultList();
		return bookList;
	}

	@Override
	public List<Book> displayByModel(String author) {
		String qStr = "SELECT book FROM Book book WHERE book.author=:pAuthor";
		TypedQuery<Book> query = em.createQuery(qStr, Book.class);
		query.setParameter("pModel", author);
		List<Book> bookList = query.getResultList();
		return bookList;
	}

	@Override
	public List<Book> displayBooksInRange(double low, double high) {
		String qStr = "SELECT book FROM Book book WHERE book.price between :low and :high";
		TypedQuery<Book> query = em.createQuery(qStr, Book.class);
		query.setParameter("low", low);
		query.setParameter("high", high);
		List<Book> bookList = query.getResultList();
		return bookList;
	}

	@Override
	public String authorName(int id) {
		String str="Not Updated Yet";
		return str;
	}

	@Override
	public void commitTransaction() {
		em.getTransaction().commit();
	}

	@Override
	public void beginTransaction() {
		em.getTransaction().begin();
	}

	@Override
	public void addBook(Book b) {
		em.persist(b);
	}

	@Override
	public void addAuthor(Author a) {
		em.persist(a);
	}

}
