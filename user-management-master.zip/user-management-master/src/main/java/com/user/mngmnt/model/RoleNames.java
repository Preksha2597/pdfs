package com.user.mngmnt.model;

public enum RoleNames {
	ADMIN, USER;
}
