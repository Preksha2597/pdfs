package com.user.mngmnt.constants;

public class AppConstant {

	public static final String SUCCESS = "success";
	public static final String FAIL = "fail";

}
