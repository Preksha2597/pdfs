package com.user.mngmnt.dto;

public class LoginDTO {

	private String emailAddrss;
	private String pswd;

	public String getEmailAddrss() {
		return emailAddrss;
	}

	public void setEmailAddrss(String emailAddrss) {
		this.emailAddrss = emailAddrss;
	}

	public String getPswd() {
		return pswd;
	}

	public void setPswd(String pswd) {
		this.pswd = pswd;
	}

}
