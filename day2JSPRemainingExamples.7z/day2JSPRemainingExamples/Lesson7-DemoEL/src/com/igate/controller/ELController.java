package com.igate.controller;

import com.cg.dto.Dog;
import com.cg.dto.Employee;
import java.io.IOException;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class ELController
  extends HttpServlet
{
  private static final long serialVersionUID = 1L;
  
  protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException
  {
    Dog dog = new Dog();
    
    dog.setName("Tommy");
    dog.setBreed("Beagle");
    
    Employee employee = new Employee();
    
    employee.setEid(100);
    employee.setEnm("Xavier");
    employee.setEsl(33333.33D);
    employee.seteDog(dog);
    
    getServletContext().setAttribute("employee", employee);
    
    response.sendRedirect("object/employeeInfo.jsp");
  }
  
  protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException
  {}
}
