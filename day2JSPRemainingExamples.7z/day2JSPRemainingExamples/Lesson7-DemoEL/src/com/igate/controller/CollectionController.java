package com.igate.controller;

import com.cg.dto.Employee;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class CollectionController
  extends HttpServlet
{
  private static final long serialVersionUID = 1L;
  
  protected void doGet(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException
  {
    ArrayList<String> nameList = new ArrayList();
    
    nameList.add("Rama");
    nameList.add("Sita");
    nameList.add("Lava");
    nameList.add("Kusha");
    
    ArrayList<Employee> employeeList = new ArrayList();
    
    Employee e1 = new Employee(100, "Rama", 33333.33D);
    Employee e2 = new Employee(101, "Sita", 22222.22D);
    Employee e3 = new Employee(102, "Lava", 22222.22D);
    Employee e4 = new Employee(103, "Kusha", 22222.22D);
    
    employeeList.add(e1);
    employeeList.add(e2);
    employeeList.add(e3);
    employeeList.add(e4);
    
    HashMap<Long, String> nameIdMap = new HashMap();
    
    nameIdMap.put(Long.valueOf(100L), "Rama");
    nameIdMap.put(Long.valueOf(101L), "Sita");
    nameIdMap.put(Long.valueOf(102L), "Lava");
    nameIdMap.put(Long.valueOf(103L), "Kusha");
    
    HashMap<String, String> nameDomainMap = new HashMap();
    
    nameDomainMap.put("Rama", "JEE");
    nameDomainMap.put("Sita", ".Net");
    nameDomainMap.put("Lava", "VnV");
    nameDomainMap.put("Kusha", "BI");
    
    getServletContext().setAttribute("nameList", nameList);
    getServletContext().setAttribute("employeeList", employeeList);
    getServletContext().setAttribute("nameIdMap", nameIdMap);
    getServletContext().setAttribute("nameDomainMap", nameDomainMap);
    
    response.sendRedirect("collection/collection.jsp");
  }
  
  protected void doPost(HttpServletRequest request, HttpServletResponse response)
    throws ServletException, IOException
  {}
}
