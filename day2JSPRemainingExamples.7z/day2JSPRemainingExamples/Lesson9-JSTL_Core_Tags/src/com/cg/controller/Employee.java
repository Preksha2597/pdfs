package com.cg.controller;

public class Employee
{
  private int eid;
  private String enm;
  private double esl;
  
  public int getEid()
  {
    return this.eid;
  }
  
  public void setEid(int eid)
  {
    this.eid = eid;
  }
  
  public String getEnm()
  {
    return this.enm;
  }
  
  public void setEnm(String enm)
  {
    this.enm = enm;
  }
  
  public double getEsl()
  {
    return this.esl;
  }
  
  public void setEsl(double esl)
  {
    this.esl = esl;
  }
}
