package com.cg.list;
import java.util.ArrayList;
import java.util.Scanner;

public class AddEmployeeArrayList {
	public static void main(String[] args) {
		ArrayList<Employee> list=new ArrayList<Employee>();
		Scanner sc=new Scanner(System.in);
		System.out.print("Enter The Number Of Employees To Be Added: ");
		int n=sc.nextInt();
		for(int i=0;i<n;i++) {
			Employee e1=new Employee();
			System.out.print("Enter Name Of Employee "+(i+1)+": ");
			String name=sc.next();
			System.out.print("Enter Age Of Employee "+(i+1)+": ");
			int age=sc.nextInt();
			System.out.print("Enter Contact Number Of Employee "+(i+1)+": ");
			long mobile=sc.nextLong();
			System.out.print("Enter e-Mail Of Employee "+(i+1)+": ");
			String mail=sc.next();
			System.out.println();
			e1.setAge(age);
			e1.setName(name);
			e1.setContact(mobile);
			e1.setId(mail);
			list.add(e1);
		}
		for(Employee e:list) {
			System.out.println(e);
		}
		
		System.out.println("Enter Employee Name: ");
		String n1=sc.next();
		for(Employee e:list) {
			if((e.getName()).equals(n1)) {
				//System.out.println(e);
				list.remove(e);
			}
		}
		
		/*for(Employee e:list) {
			System.out.println(e);
		}*/
		System.out.println(list);
	}
}
