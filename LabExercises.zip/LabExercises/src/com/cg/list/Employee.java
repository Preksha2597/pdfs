package com.cg.list;

public class Employee {
		private String name;
		private int age;
		private String id;
		private long contact;
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public int getAge() {
			return age;
		}
		public void setAge(int age) {
			this.age = age;
		}
		public String getId() {
			return id;
		}
		public void setId(String id) {
			this.id = id;
		}
		public long getContact() {
			return contact;
		}
		public void setContact(long contact) {
			this.contact = contact;
		}
		@Override
		public String toString() {
			return "Employee [name=" + name + ", age=" + age + ", id=" + id + ", contact=" + contact + "]";
		}
		
}
