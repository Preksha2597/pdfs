package com.cg.basics;
import java.util.Scanner;

class Operations{
	public void add(double a,double b) {
		double sum=a+b;
		System.out.println(sum);
	}
	public void subtract(double a,double b) {
		double sub=a-b;
		System.out.println(sub);
	}
	public void multiply(double a,double b) {
		double mul=a*b;
		System.out.println(mul);
	}
	public void divide(double a,double b) {
		double div=a/b;
		System.out.println(div);
	}
}

public class Calculator {
	static String cp;
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);		       
		do {
        	System.out.println("Enter First Number: ");
    		double a=sc.nextDouble();
    		System.out.println("Enter Second Number: ");
    		double b=sc.nextDouble();
        	System.out.println("1. Add");
			System.out.println("2. Subtract");
			System.out.println("3. Multiply");
			System.out.println("4. Divide");
			System.out.println("5. Exit");
			System.out.println("Enter Your Choice");
			int k=sc.nextInt();
			Operations o=new Operations();
			switch(k) {
			case 1: o.add(a,b);
			break;
			case 2: o.subtract(a,b);
			break;
			case 3: o.multiply(a,b);
			break;
			case 4: o.divide(a,b);
			break;
			case 5: System.exit(0);
			break;
			}
			System.out.println("Do You Want To Continue ? Y/N");
			cp=sc.next();
        }while(cp.equals("Y"));
	}
}
