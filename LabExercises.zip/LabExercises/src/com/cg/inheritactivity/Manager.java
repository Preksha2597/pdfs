package com.cg.inheritactivity;

public class Manager extends Employee{
	
	public Manager(long empid, String empname, String empadd, long empph, double salary) {
		super(empid, empname, empadd, empph);
		this.basicsal=salary;
	}	
	
	double calculateTransAllow() {
		travelallow = 0.15*basicsal;
		System.out.println("Travel Allowance: "+travelallow);
		return travelallow;
	}
}
