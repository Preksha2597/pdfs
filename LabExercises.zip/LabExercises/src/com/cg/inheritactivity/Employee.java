package com.cg.inheritactivity;

public class Employee {
	long empid;
	String empname;
	String empadd;
	long empph;
	double basicsal;
	double specallow=250.80;
	double hra=1000.50;
	double travelallow;
	
	public Employee(long empid, String empname,String empadd, long empph) {
		this.empid=empid;
		this.empname=empname;
		this.empadd=empadd;
		this.empph=empph;
	}
	
	double calculateSalary() {
		double salary=0;
		salary = basicsal + (basicsal*specallow/100) + (basicsal*hra/100); 
		System.out.println("Salary: "+salary);
		return salary;
	}
	
	double calculateTransAllow() {
		travelallow = 0.10*basicsal;
		System.out.println("Travel Allowance: "+travelallow);
		return travelallow;
	}
	
}
