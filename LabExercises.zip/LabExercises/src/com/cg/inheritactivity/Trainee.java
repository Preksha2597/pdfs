package com.cg.inheritactivity;

public class Trainee extends Employee{
	
	public Trainee(long empid, String empname, String empadd, long empph, double salary) {
		super(empid, empname, empadd, empph);
		this.basicsal=salary;
	}

}
