package com.cg.lab7;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.Scanner;

public class Program_7_1 {
	public static void main(String[] args) {
		List<String> productName = new ArrayList<String>();
		productName.add("ABC");
		productName.add("FGH");
		productName.add("CDE");
		productName.add("JKL");
		productName.add("DEF");
		Collections.sort(productName);
		Iterator itr=productName.iterator();
		while(itr.hasNext()) {
			System.out.println(itr.next());
		}
		
		Scanner sc=new Scanner(System.in);
		String name[]=new String[5];
		for(int i=0;i<5;i++) {
			name[i]=sc.next();
		}
		Arrays.sort(name);
		for(String s:name) {
			System.out.println(s);
		}
	}
}
