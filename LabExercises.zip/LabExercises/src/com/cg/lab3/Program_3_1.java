package com.cg.lab3;
import java.util.Scanner;

public class Program_3_1 {
	public static void main(String args[]) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter The String: ");
		String s=sc.next();
		System.out.println("1. Add String To Itself: ");
		System.out.println("2. Replace Odd Positions With #: ");
		System.out.println("3. Remove Duplicate Characters: ");
		System.out.println("4. Change Odd Characters To Uppercase: ");
		int k=sc.nextInt();
		String s2="";
		switch(k) {
		case 1:
		s2=s.concat(s);
		break;
		
		case 2:
			s2=s;
			for(int i=0;i<s.length();i=i+2) {
				s2=s.replace(s.charAt(i), '#');
		}
		break;
		
		case 3:
		for(int i=0;i<s.length();i++) {
			if(s2.contains(s.charAt(i)+"")) {}
			else
				s2=s2+s.charAt(i);
		}break;
		
		case 4:
		for(int i=0;i<s.length();i=i+2) {
			s2=s.replace(s.charAt(i), (char) (s.charAt(i)-32));
		}break;
		}
		System.out.println(s2);
	}
}
