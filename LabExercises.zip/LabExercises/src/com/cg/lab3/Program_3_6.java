package com.cg.lab3;

import java.time.LocalDate;
import java.time.LocalTime;
import java.time.ZoneId;
import java.util.Scanner;

public class Program_3_6 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Zone ID: ");
		ZoneId id=ZoneId.of(sc.nextLine());
		System.out.println(LocalDate.now(id));
		System.out.println(LocalTime.now(id));
	}
}
