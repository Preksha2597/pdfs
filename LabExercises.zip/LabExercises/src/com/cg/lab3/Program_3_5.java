package com.cg.lab3;
import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;

public class Program_3_5 {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Date Of Purchase->");
		System.out.print("Date As DD: ");
		int d=sc.nextInt();
		System.out.print("Month As MM: ");
		int m=sc.nextInt();
		System.out.print("Year As YYYY: ");
		int y=sc.nextInt();
		Period p1 = Period.of(y,m,d); 
		
		System.out.println();
		System.out.println("Enter Warranty Period->");
		System.out.print("Months: ");
		int wm=sc.nextInt();
		System.out.print("Years: ");
		int wy=sc.nextInt();
		int wd=0;
		Period p2 = Period.of(wy,wm,wd); 
		
		p1=(p1.plus(p2));
		int df=p1.getDays();
		int mf=p1.getMonths();
		int yf=p1.getYears();
		if(mf>12) {
			mf=mf-12;
			yf=yf+1;
		}
		if(df>28 && mf==2) {
			if((yf%400==0 || (yf%4==0 && yf%100!=0)) && (df>29)){
				mf=mf+1;
				df=df-29;
			}
			else {
				mf=mf+1;
				df=df-28;
			}
			
		}
		LocalDate date = LocalDate.of(yf, mf, df);
		System.out.println("Warranty Will Expire On-> "+date);
	}

}
