package com.cg.lab3;
import java.util.Scanner;
import java.time.LocalDate;
import java.time.Period;
import java.util.*;

public class Program_3_3 {

	public static void main(String args[]) {
		LocalDate date2;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Date-> As DD MM YYYY:");
		int d=sc.nextInt();
		int m=sc.nextInt();
		int y=sc.nextInt();
		
		LocalDate today=LocalDate.now();
		date2=LocalDate.of(y, m, d);
		Program_3_3 d1=new Program_3_3();
		Period p=Period.between(date2, today);
		System.out.print(p.getYears()+" Years ");
		System.out.print(p.getMonths()+" Months ");
		System.out.println(p.getDays()+" Days");
	}
}
