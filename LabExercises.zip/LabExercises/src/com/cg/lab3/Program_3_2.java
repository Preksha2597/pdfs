package com.cg.lab3;
import java.util.Scanner;

public class Program_3_2 {
	
	static void positive(String str) {
		int len=str.length();
		boolean flag=true;
		for(int i=0;i<len;i++) {
			for(int j=i+1;j<len;j++) {
			if((int)str.charAt(i)>(int)str.charAt(j)){
				flag=false;
			}
			}
		}
			if(flag==true)
				System.out.println("String Is Positive");
			else
				System.out.println("String Is Negative");
	}
	public static void main(String args[]) {
		String s1;
		Scanner sc=new Scanner(System.in);
		s1=sc.next();
		positive(s1);
	}
}
