package com.cg.lab2;
import java.time.LocalDate;
import java.time.Period;
import java.util.Scanner;


public class PersonMain {
	private LocalDate today;
	String fname,lname;
	char gender;
	public PersonMain(String fname,String lname,char gender) {
		this.fname=fname;
		this.lname=lname;
		this.gender=gender;
	}
	
	long phone() {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Phone Number : ");
		long pn=sc.nextLong();
		return pn;
	}
	
	/*void calculateAge(int day, int month, int year) {
		LocalDate today=new LocalDate();
		dat=LocalDate
		
		Period p=Period.between(d1, today);
		System.out.println(p.getYears()+" Years "+p.getMonths()+" Months "+p.getDays()+" Days");
	}*/
	
	void printdata(long pn) {
	System.out.println("First Name: "+fname);
	System.out.println("Last Name: "+lname);
	System.out.println("Gender: "+gender);	
	System.out.println("Phone Number: "+pn);	
	}
}
