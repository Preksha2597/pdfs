package com.cg.lab2;
import java.util.Scanner;

public class Program_2_2 {
	public static void main(String[] args) {
		int num=Integer.parseInt(args[0]);
		if(num>=0)
			System.out.println("Positive");
		else
			System.out.println("Negative");
		}
}
