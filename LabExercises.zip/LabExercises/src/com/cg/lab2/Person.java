package com.cg.lab2;
import java.time.LocalDate;
import java.util.Scanner;

class EmptyNameException extends Exception{
	EmptyNameException(String msg){
		super(msg);
	}
}

class EmptyFNameException extends Exception{
	EmptyFNameException(String msg){
		super(msg);
	}
}

class EmptyLNameException extends Exception{
	EmptyLNameException(String msg){
		super(msg);
	}
}

public class Person extends Exception{
	static String fname;
	static String lname;

	public static void main(String args[]) throws Exception{
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter First Name: ");
		fname = sc.nextLine();
		System.out.println("Enter Last Name: ");
		lname = sc.nextLine();
		try{
			if(fname.equals("")&&lname.equals(""))
				throw new EmptyNameException("First Name & Last Name Not Entered");
			else if(fname.equals(""))
				throw new EmptyFNameException("First Name Not Entered");
			else if(lname.equals(""))
				throw new EmptyFNameException("Last Name Not Entered");
		}
		catch(Exception e){
			System.out.println(e);
		}
	
		/*System.out.println("Enter Gender : ");
		char gender = sc.next().charAt(0);
		PersonMain d1 = new PersonMain(fname, lname, gender);
		long pn=d1.phone();
		d1.printdata(pn);*/
	}
}
