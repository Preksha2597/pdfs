package com.cg.lab2;
import java.util.Scanner;

public class Program_2_1 {
	
	public static void print(String fn, String ln, char gen, int age, float wt, int pn) {
		System.out.println("First Name: "+fn);
		System.out.println("Last Name: "+ln);
		System.out.println("Gender: "+gen);
		System.out.println("Age: "+age);
		System.out.println("Weight "+wt);
		System.out.println("Phone Number:  "+wt);
	}
	
	public static void main(String args[]) {
		String fn;
		String ln;
		char gen;
		int age,pn;
		float wt;
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter First Name : ");
		fn=sc.next();
		System.out.println("Enter Last Name : ");
		ln=sc.next();
		System.out.println("Enter Gender (M/F) : ");
		gen=sc.next().charAt(0);
		System.out.println("Enter Age : ");
		age=sc.nextInt();
		System.out.println("Enter Weight : ");
		wt=sc.nextFloat();
		System.out.println("Enter Phone Number : ");
		pn=sc.nextInt();
		print(fn,ln,gen,age,wt,pn);
	}
}
