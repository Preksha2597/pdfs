package com.cg.lab4;
import java.util.Scanner;

public class Account {
	long accNum;
	double balance=0;
	Person accHolder;
	Scanner sc=new Scanner(System.in);
	
	void deposit(double dep) {
		System.out.println("Account Number: "+accNum);
		System.out.println("Name: "+accHolder);
		System.out.println("Rs."+dep+" Has Been Deposited");
		balance=balance+dep;
		System.out.println("Updated Balance: Rs."+balance);
		System.out.println();
		
	}

	void withdraw(double wdrw) {
		if(balance>=100+wdrw) {
			System.out.println("Account Number: "+accNum);
			System.out.println("Name: "+accHolder);
			System.out.println("Rs."+wdrw+" Has Been Withdrawn");
			balance=balance-wdrw;
			System.out.println("Updated Balance: Rs."+balance);
			System.out.println();
		}
		else {
			System.out.println("Account Number: "+accNum);
			System.out.println("Name: "+accHolder);
			System.out.println("Balance Insufficient To Withdraw Rs."+wdrw);
			System.out.println("Current Balance: Rs."+balance);
			System.out.println();
		}
	}
	double getBalance() {
		System.out.println("Account Number: "+accNum);
		System.out.println("Name: "+accHolder);
		System.out.println();
		return balance;
	}
}
