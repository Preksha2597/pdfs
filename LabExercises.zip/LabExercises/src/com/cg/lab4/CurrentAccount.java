package com.cg.lab4;

public class CurrentAccount extends Account{
	final double overdraftLimit=25000;
	final double minBal=500;
	double withdrawn=0;
	void withdraw(double wdrw) {
		
		if(balance>=minBal+wdrw && overdraftLimit<=wdrw+withdrawn) {
			System.out.println("Account Number: "+accNum);
			System.out.println("Name: "+accHolder);
			System.out.println("Rs."+wdrw+" Has Been Withdrawn");
			balance=balance-wdrw;
			System.out.println("Updated Balance: Rs."+balance);
			withdrawn=wdrw+withdrawn;
			
		}
		else if(overdraftLimit>wdrw+withdrawn) {
			System.out.println("Account Number: "+accNum);
			System.out.println("Name: "+accHolder);
			System.out.println("Overdraft Balance Reached To Withdraw Rs."+wdrw);
			System.out.println("Current Balance: Rs."+balance);
		}
		else {
			System.out.println("Account Number: "+accNum);
			System.out.println("Name: "+accHolder);
			System.out.println("Balance Insufficient To Withdraw Rs."+wdrw);
			System.out.println("Current Balance: Rs."+balance);
		}
	}
}
