package com.cg.lab4;

public class SavingsAccount extends Account{
	final double minBal=500;
	
	void withdraw(double wdrw) {
		if(balance>=minBal+wdrw) {
			System.out.println("Account Number: "+accNum);
			System.out.println("Name: "+accHolder);
			System.out.println("Rs."+wdrw+" Has Been Withdrawn");
			balance=balance-wdrw;
			System.out.println("Updated Balance: Rs."+balance);
		}
		else {
			System.out.println("Account Number: "+accNum);
			System.out.println("Name: "+accHolder);
			System.out.println("Balance Insufficient To Withdraw Rs."+wdrw);
			System.out.println("Current Balance: Rs."+balance);
		}
	}
}
