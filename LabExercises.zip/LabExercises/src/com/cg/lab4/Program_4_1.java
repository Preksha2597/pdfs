package com.cg.lab4;

public class Program_4_1 {
	public static void main(String args[]) {
		Person p1=new Person();
		p1.age=40;
		p1.name="Smith";
		
		Person p2=new Person();
		p2.age=35;
		p2.name="Kathy";
		
		Account a1=new Account();
		a1.accNum=123456789;
		a1.balance=2000;
		a1.accHolder=p1;
		
		Account a2=new Account();
		a2.accNum=234567891;
		a2.balance=3000;
		a2.accHolder=p2;
		
		a1.deposit(20000);
		a2.withdraw(20000);
		a2.withdraw(2500);
		a2.withdraw(500);
		a1.getBalance();
		a2.getBalance();
	}
}
