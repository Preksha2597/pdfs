package com.cg.lab8;

import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Program_8_1 {
	public static void main(String[] args) throws IOException {
		FileReader r=new FileReader("test3.txt");
		int ch;
		String str="";
		while((ch=r.read()) != -1) {
			str=str+((char)ch)+"";
		}
		r.close();
		System.out.println(str);
		String[] s=str.split("");
		String sc="";
		for(int i=s.length-1; i>=0; i--) {
			sc=sc+s[i]+"";
		}
		System.out.println(sc);
		FileWriter fw=new FileWriter("test3.txt",true);
		fw.write(sc);
		System.out.println("Success");
		fw.close();
	}
}
