package com.cg.lab8;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

public class Program_8_2 {
	public static void main(String[] args) throws IOException {
		FileWriter fw =new FileWriter("numbers.txt");
		String s="1,2,3,4,5,6,7,8,9,10";
		fw.write(s);
		fw.close();
		FileReader fr=new FileReader("numbers.txt");
		Scanner sc=new Scanner(System.in);
		String s1=sc.next();
		String nums[]=s1.split(",");
		for(String num:nums) {
			int n=Integer.parseInt(num);
			if(n%2==0) {
				System.out.println(n);
			}
		}
		fr.close();
	}
}
