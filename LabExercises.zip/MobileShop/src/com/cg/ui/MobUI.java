package com.cg.ui;

import java.sql.Date;
import java.time.LocalDate;
import java.util.Scanner;

import com.cg.bean.Customer;
import com.cg.service.IMobService;
import com.cg.service.MobServiceImpl;

public class MobUI {
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		IMobService service=new MobServiceImpl();
		
		while(true) {
			System.out.println("\nEnter Your Choice: ");
			System.out.println("1. Insert Customer");
			System.out.println("2. Purchase Mobile(s)");
			System.out.println("3. Display All Mobiles");
			System.out.println("4. Delete Mobile");
			System.out.println("5. Search Mobile By Range");
			System.out.println("6. Insert And Search Mobile Service");
			System.out.println("7. Exit");
			int m=sc.nextInt();
			switch(m) {
			case 1:	
				Customer c=new Customer();
				System.out.println("Enter Customer Name:");
				c.setName(sc.next());
				
					System.out.println("Enter Customer E-Mail ID:");
					String email1=sc.next();
					while(!(email1.matches("[a-zA-Z0-9[!#$%&'()*+,/\\-_\\.\"]]+@[a-zA-Z0-9[!#$%&'()*+,/\\-_\"]]+\\.[a-zA-Z0-9[!#$%&'()*+,/\\-_\"\\.]]+"))) {
						System.out.println("Enter A Valid E-Mail");
						email1=sc.next();
					}
					c.setCustid(email1);

				
				System.out.println("Enter Customer's Mobile Number:");
				String mobile1=sc.next();
				//while(!(mobile1.matches("[0-9]{10}"))) {
				while(!(mobile1.matches("(91/0)?[6-9][0-9]{9}"))) {
					System.out.println("Enter A Valid Mobile Number: 10 Digits, Positive Integer, Starts With 6/7/8/9");
					mobile1=sc.next();
				}
				c.setPhoneno(mobile1);
				
				System.out.println("Enter Mobile ID:");
				String mobid1=sc.next();
				while(!(mobid1.matches("[0-9]{4}"))) {
					System.out.println("Enter A Valid Mobile ID: 4 Digits, Positive Integer");
					mobid1=sc.next();
				}
				c.setPhoneno(mobile1);
				service.insertCust(c);
				break;
			case 2:
				System.out.println("Enter Customer E-Mail ID:");
				String email2=sc.next();
				while(!(email2.matches("[a-zA-Z0-9[!#$%&'()*+,/\\-_\\.\"]]+@[a-zA-Z0-9[!#$%&'()*+,/\\-_\"]]+\\.[a-zA-Z0-9[!#$%&'()*+,/\\-_\"\\.]]+"))) {
					System.out.println("Enter A Valid E-Mail");
					email2=sc.next();
				}
				System.out.println("Enter Mobile ID:");
				String mobid2=sc.next();
				while(!(mobid2.matches("[0-9]{4}"))) {
					System.out.println("Enter A Valid Mobile ID: 4 Digits, Positive Integer");
					mobid2=sc.next();
				}
				System.out.println("Enter Quantity To Purchase:");
				int quantity2=sc.nextInt();
				int quantity21;
				if(quantity2>0) {
					quantity21=quantity2;}
				else {
					System.out.println("Enter Positive Integer Value");
					break;
				}
				service.updateMobile(quantity21, email2, mobid2);
				break;
			case 3:
				service.allMobiles();
				break;
			case 4:
				System.out.println("Enter Mobile ID:");
				String mobid4=sc.next();
				while(!(mobid4.matches("[0-9]{4}"))) {
					System.out.println("Enter A Valid Mobile ID: 4 Digits, Positive Integer");
					mobid4=sc.next();
				}
				service.deleteMobile(mobid4);
				break;
			case 5:
				System.out.println("Enter Lower Range:");
				double low5=sc.nextDouble();
				System.out.println("Enter Higher Range:");
				double high5=sc.nextDouble();
				service.searchMobile(low5, high5);
			case 6:
				System.out.println("Option Not Available");
				break;
			case 7:
				System.exit(0);
				break;
			default:
				System.out.println("Invalid Input");
				break;
			}
		}
	
	}
}
