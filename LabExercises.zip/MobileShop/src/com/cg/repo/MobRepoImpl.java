package com.cg.repo;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import com.cg.bean.Customer;

public class MobRepoImpl implements IMobRepo {
	private Connection con=null;
	private PreparedStatement ps=null;
	private PreparedStatement qs=null;
	public void getConnection() throws ClassNotFoundException, SQLException {
		Scanner sc=new Scanner(System.in);
		Class.forName("oracle.jdbc.driver.OracleDriver");
		String url="jdbc:oracle:thin:@localhost:1521:XE";
		String user="system";
		String pass="Capgemini123";
		con=DriverManager.getConnection(url, user, pass);
	}
	
	@Override
	public void insertCust(Customer c) {
		try {
			getConnection();
			ps=con.prepareStatement("insert into Customer values(?,?,?,?,PurIDSeq.nextval,current_timestamp)");
			ps.setString(1, c.getName());
			ps.setString(2, c.getCustid());
			ps.setString(3, c.getPhoneno());
			ps.setString(4, c.getMobid());
			ps.executeUpdate();
			System.out.println("Customer Added");
			con.close();
		}catch(Exception e) {
			System.out.println(e);
		}
		
	}

	@Override
	public void updateMobile(int quantity, String email, String mobid) {
		try {
			getConnection();
			ps=con.prepareStatement("select Stock from Mobile where MobID=?");
			ps.setString(1, mobid);
			int stock=0;
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				stock=rs.getInt(1);
				System.out.println("Stock: "+rs.getInt(1));
			}
			if(stock>quantity) {
				stock=stock-quantity;
				System.out.println(quantity+" Mobile(s) Of Mobile ID "+mobid+" Purchased By "+email);
				qs=con.prepareStatement("update Mobile set Stock=? where MobID=?");
				qs.setInt(1, stock);
				qs.setString(2, mobid);
				qs.executeUpdate();
				System.out.println("Updated Stock: "+stock);
			}
			else if(stock<quantity) {
				System.out.println("Only "+stock+ " Mobiles Left In Stock\n"+quantity+" Can't Be Purchased");
			}
			else {
			}
			con.close();
		}catch(Exception e) {
			System.out.println(e);
		}
	}

	@Override
	public void allMobiles() {
		try {
			getConnection();
			ps=con.prepareStatement("select * from Mobile");
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				System.out.print("Mobile ID: "+rs.getString(1)+" || ");
				System.out.print("Mobile Name: "+rs.getString(2)+" || ");
				System.out.print("Price: "+rs.getDouble(3)+" || ");
				System.out.print("Stock: "+rs.getInt(4)+" || ");
				System.out.println();
			}
			con.close();
		}catch(Exception e) {
			System.out.println(e);
		}
	}

	@Override
	public void deleteMobile(String mobid) {
		try {
			getConnection();
			ps=con.prepareStatement("delete from Mobile where MobID=?");
			ps.setString(1, mobid);
			ps.executeUpdate();
			con.close();
		}catch(Exception e) {
			System.out.println(e);
		}
	}

	@Override
	public void searchMobile(double low, double high) {
		try {
			getConnection();
			ps=con.prepareStatement("select * from Mobile where Price<? and Price>?");
			ps.setDouble(1, high);
			ps.setDouble(2, low);
			ResultSet rs=ps.executeQuery();
			while(rs.next()) {
				System.out.print("Mobile ID: "+rs.getString(1)+" || ");
				System.out.print("Mobile Name: "+rs.getString(2)+" || ");
				System.out.print("Price: "+rs.getDouble(3)+" || ");
				System.out.print("Stock: "+rs.getInt(4)+" || ");
				System.out.println();
			}
			con.close();
		}
			catch(Exception e) {
			System.out.println(e);
		}
	}

}
