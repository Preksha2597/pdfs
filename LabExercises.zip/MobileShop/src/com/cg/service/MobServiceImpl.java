package com.cg.service;

import com.cg.bean.Customer;
import com.cg.repo.IMobRepo;
import com.cg.repo.MobRepoImpl;

public class MobServiceImpl implements IMobService{
	IMobRepo cust=new MobRepoImpl();
	@Override
	public void insertCust(Customer c) {
		cust.insertCust(c);
	}

	@Override
	public void updateMobile(int quantity, String email, String mobid) {
		cust.updateMobile(quantity, email, mobid);
	}

	@Override
	public void allMobiles() {
		cust.allMobiles();
	}

	@Override
	public void deleteMobile(String mobid) {
		cust.deleteMobile(mobid);
	}

	@Override
	public void searchMobile(double low, double high) {
		cust.searchMobile(low, high);
	}

}
