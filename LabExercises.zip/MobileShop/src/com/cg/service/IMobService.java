package com.cg.service;

import com.cg.bean.Customer;

public interface IMobService {
	public void insertCust(Customer c);
	public void updateMobile(int quantity, String email, String mobid);
	public void allMobiles();
	public void deleteMobile(String mobid);
	public void searchMobile(double low, double high);
}
