package com.cg.bean;

public class Mobile {
	private String mobid;
	private String mobname;
	private double price;
	private int stock;
	public String getMobid() {
		return mobid;
	}
	public void setMobid(String mobid) {
		this.mobid = mobid;
	}
	public String getMobname() {
		return mobname;
	}
	public void setMobname(String mobname) {
		this.mobname = mobname;
	}
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	public int getQuantity() {
		return stock;
	}
	public void setQuantity(int quantity) {
		this.stock = quantity;
	}
	@Override
	public String toString() {
		return "Mobile [mobid=" + mobid + ", mobname=" + mobname + ", price=" + price + ", quantity=" + stock + "]";
	}
	
}
