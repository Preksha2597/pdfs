package com.cg.bean;

import java.sql.Date;

public class Customer {
	private String name;
	private String custid;
	private String phoneno;
	private String mobid;
	private String purchaseid;
	private Date purchasedate;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getCustid() {
		return custid;
	}
	public void setCustid(String custid) {
		this.custid = custid;
	}
	public String getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(String phoneno) {
		this.phoneno = phoneno;
	}
	public String getMobid() {
		return mobid;
	}
	public void setMobid(String mobid) {
		this.mobid = mobid;
	}
	public String getPurchaseid() {
		return purchaseid;
	}
	public void setPurchaseid(String purchaseid) {
		this.purchaseid = purchaseid;
	}
	public Date getPurchasedate() {
		return purchasedate;
	}
	public void setPurchasedate(Date purchasedate) {
		this.purchasedate = purchasedate;
	}
	@Override
	public String toString() {
		return "Customer [name=" + name + ", custid=" + custid + ", phoneno=" + phoneno + ", mobid=" + mobid
				+ ", purchaseid=" + purchaseid + ", purchasedate=" + purchasedate + "]";
	}
	
}
