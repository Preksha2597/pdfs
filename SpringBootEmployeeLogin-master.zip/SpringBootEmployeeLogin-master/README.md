# SpringBootEmployeeLogin
This project was made as a way to make a first contact with SpringBoot and JavaScript as part of my internship at Comtrade Group in Belgrade, Serbia
It uses SpringBoot, Maven and Java to build a mySQL database that holds employee information such as first name, last name and salary.

